const env = {
  "MONGO_ATLAS_PASSWORD": "test",
  "JWT_KEY": "Esta_es_la_secret_key_para_jwt"
};

module.exports = env;
