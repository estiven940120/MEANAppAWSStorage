const env = {
	AWS_ACCESS_KEY: 'AKIA3XKKKLDXWJ4WUBXR',
	AWS_SECRET_ACCESS_KEY: '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',
	REGION : 'us-east-2',
	Bucket: 'pacientesgruneco'
};

module.exports = env;
